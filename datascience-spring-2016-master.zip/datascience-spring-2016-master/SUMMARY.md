# Summary

* [README.md](README.md)
* [Syllabus](syllabus.md)
* [Introduction](notes/introduction.md)
   * [Homework 1](notes/homeworks/homework1.md)
* [Data Acquisition](notes/data_acquisition.md)
   * [Homework 2](notes/homeworks/homework2.md)
* [Data Storage](notes/data_storage.md)
   * Homework 3
* [Data Analysis](notes/data_analysis.md)
   * Homework 4
* [Data Visualization](notes/data_visualization.md)
   * Project
