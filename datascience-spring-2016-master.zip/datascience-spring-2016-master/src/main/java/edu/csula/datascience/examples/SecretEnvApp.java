package edu.csula.datascience.examples;

/**
 * Created by eric on 4/10/16.
 */
public class SecretEnvApp {
    public static void main(String[] args) {
        System.out.println(System.getenv("KEY")+"hey!");
    }
}
