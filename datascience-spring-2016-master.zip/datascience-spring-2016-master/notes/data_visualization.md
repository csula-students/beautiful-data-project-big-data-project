# Data Visualization

We've got some conclusions out of the data. How do we report this data to others?


## Objectives

* Basic chart types
  * Bar chart, pie chart, line chart, heap map, geo map ... etc
* Basic JavaScript, HTML and CSS review
* D3
* Python chart

## Metrics

* Visualization of data